# REFERENCE_LIBRARY_PILOT_V0_1_RESULTS_SYNTHESIS

## Result

Thirty of thirty G01D clips now have isolated normalized **candidate** records. The package validates all identity, failure, byte, UNKNOWN, rights, score, semantic, and CLIP-005 execution invariants. Existing conversation records were not replaced.

## Stable findings supported by the 30-clip evidence

1. **P480 is the default semantic index** for ordinary narrative, performance, action, and long-form content.
2. **P360 is a coarse routing or sole-available index**, especially after higher-tier technical failure or for simple high-contrast compositing utilities.
3. **P720 is an escalation or targeted-segment source**, not a universal retention tier. Its gain must be separated into semantic, temporal, and spatial-detail dimensions.
4. Storage state must distinguish technical validation, availability, lifecycle, execution history, proposals, human decisions, and executed facts.
5. Scores are descriptive only and never automatic retention/deletion gates. UNKNOWN is never zero.
6. Proxy black backgrounds do not determine original alpha; proxy watchability does not prove production compositing suitability.
7. Purchased provenance does not grant active-generation-input or publication rights.

## Remaining unresolved items

- `narrative_reference` remains a taxonomy decision.
- Exact duplicate or upstream overlap remains UNKNOWN without a separate evidence route.
- Original alpha, orientation causes, source hashes, and production suitability remain UNKNOWN where not already evidenced.
- Storage deletion candidates remain proposals only.

## Source boundary

The next meaningful operation is no longer another record-normalization pass. It is preparation and human review of a Project Source update evidence package deciding which validated stable rules should be promoted, which remain provisional, and which case facts stay only in audit evidence. No Project Source file has been changed.
