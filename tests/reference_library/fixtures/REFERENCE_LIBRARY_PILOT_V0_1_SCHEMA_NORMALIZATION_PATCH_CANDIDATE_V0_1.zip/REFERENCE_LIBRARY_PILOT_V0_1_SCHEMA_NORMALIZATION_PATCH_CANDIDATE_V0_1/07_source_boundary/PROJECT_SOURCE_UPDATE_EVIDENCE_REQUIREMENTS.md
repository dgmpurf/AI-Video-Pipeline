# PROJECT SOURCE UPDATE BOUNDARY

The candidate materialization and validation chain has reached the point where further durable promotion requires a Project Source decision.

A future Source update must be separate and human-reviewed. It should consider only stable rule candidates, including:
- P480 default semantic index role;
- P720 explicit escalation reasons and gain dimensions;
- P360 coarse-route / sole-index role;
- descriptive scoring is not a deletion or retention gate;
- separation of proposal, human decision, execution, and audit facts;
- alpha/orientation/source-value UNKNOWN preservation;
- rights boundary for purchased unverified material;
- all destructive or production actions remain human-gated.

Do not promote clip-specific descriptions, bytes, hashes, one-off failures, or individual storage proposals into stable Source rules.

Current status: SOURCE_NOT_MODIFIED.
