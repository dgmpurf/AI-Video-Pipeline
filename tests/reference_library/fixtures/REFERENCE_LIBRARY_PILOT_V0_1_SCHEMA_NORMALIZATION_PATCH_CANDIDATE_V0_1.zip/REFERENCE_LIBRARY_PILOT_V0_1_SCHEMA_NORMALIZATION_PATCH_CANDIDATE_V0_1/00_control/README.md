# Reference Library Pilot V0.1 — Schema Normalization Candidate

Status: **CANDIDATE_MATERIALIZED_AND_VALIDATED_ALL_30_PASS**

This package contains 30 isolated, self-contained candidate records normalized to `REFERENCE_LIBRARY_PILOT_SCHEMA_V0_1R2`. It does **not** replace existing records and grants no media, deletion, database, repository, Git, Provider, or Official Source authority.

Core invariants:
- 30 unique records
- 14 preserved technical failures
- 57 current proxies / 267,538,642 bytes
- 4 retained segments / 31,831,333 bytes
- 299,369,975 current derived-media bytes
- CLIP-005 deleted bytes: 1,702,329,164
- Legacy unsupported UNKNOWN slots: 198
- UNKNOWN-to-zero: 0
- rights: purchased_unverified_license / active_generation_input_allowed=false / publication_allowed=UNKNOWN
- semantic changes: 0
- score changes: 0
- media operations: 0
- `narrative_reference` preserved in extension with `TAXONOMY_DECISION_REQUIRED`

See `04_validation/validation_report.json` and `06_synthesis/REFERENCE_LIBRARY_PILOT_V0_1_RESULTS_SYNTHESIS.md`.
